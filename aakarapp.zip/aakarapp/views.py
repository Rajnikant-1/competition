from urllib import request
from django.http import HttpResponse
from django.shortcuts import render, redirect
from allauth.socialaccount.models import SocialAccount
from django.contrib.auth.decorators import login_required

## import data tables from database
from .models import Submission , Seismic ,BridgeIt ,ConquerIt
re_url='/'

# Create your views here.


def registerLogiq(request):
    return render(request, "submission.html")

def msewall_view(request):
    return render(request, "msewall.html")

def idp(request):
    return render(request, "idp.html")



def index(request):
    global re_url
    re_url=request.path
    user = request.user
    is_filled = False 
    is_filled_seismic=False
    is_filled_bridgeit=False
    is_filled_conquerit=False
    if user.is_authenticated:
        email = user.email
        is_filled = len(Submission.objects.filter(email=email))==1
        is_filled_seismic = len(Seismic.objects.filter(email=email))==1
        is_filled_bridgeit=len(BridgeIt.objects.filter(email=email))==1
        is_filled_conquerit=len(ConquerIt.objects.filter(email=email))==1

    print(is_filled)

    return render(request, "index.html",
    {
        'is_filled':is_filled,
        'is_filled_seismic':is_filled_seismic,
        'is_filled_bridgeit':is_filled_bridgeit,
        'is_filled_conquerit':is_filled_conquerit
    })

def logiq(request):
    global re_url
    re_url=request.path
    user = request.user
    is_filled = False 
    if user.is_authenticated:
        email = user.email
        is_filled = len(Submission.objects.filter(email=email))==1
    return render(request, "logiq.html",
    {
        'is_filled':is_filled
    })

def submitted(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        user = request.user
        mail = user.email

        
        colgName = request.POST.get('colgName', '')
        branch = request.POST.get('branch', '')
        mobileNo = request.POST.get('mobileNo', '')
        emails = request.POST.get('emails', '')
        program = request.POST.get('program', '')
        year = request.POST.get('year', '')
        address = request.POST.get('address', '')
        roll_no = request.POST.get('roll_no', '')
        ref=request.POST.get('ref','')
        response = Submission(name=name, email=mail, colgName=colgName,branch=branch, mobileNo=mobileNo,
                              year=year, roll_no=roll_no, address=address, program=program,ref=ref, emails=emails)
        response.save()

    return  redirect('index')


def seismic(request):
    global re_url
    re_url=request.path
    user = request.user
    is_filled_seismic = False 
    if user.is_authenticated:
        email = user.email
        is_filled_seismic = len(Seismic.objects.filter(email=email))==1
        
  
    return render(request, "seismic.html",
    {
        'is_filled_seismic':is_filled_seismic
    })


def seismic_reg(request):
    if request.method == "POST":
        
        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        category = request.POST.get('category', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = Seismic(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2, 
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4, category=category, ref=ref)
        response.save()
      
        cat=response.category
        t=response.team
        # if response.category==1:
        #     print('i am category',category)

    

    return redirect('seismic')




    
def bridgeit(request):
    global re_url
    re_url=request.path
    user = request.user
    is_filled_bridgeit = False 
    if user.is_authenticated:
        email = user.email
        is_filled_bridgeit = len(BridgeIt.objects.filter(email=email))==1
        
    print(is_filled_bridgeit)
    return render(request, "bridgeit.html",
    {
        'is_filled_bridgeit':is_filled_bridgeit
    })
    
    
def bridgeit_reg(request):
    if request.method == "POST":
        
        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = BridgeIt(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2, 
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4,  ref=ref)
        response.save()

#         import datetime as dt
#         import boto3,json
#         def publish_message(message):
#             arn = ''
#             sns = boto3.resource('sns', aws_access_key_id="AKIA3TGK5AWKEZFOA2NH", 
#                              aws_secret_access_key="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",
#                              region_name='ap-south-1')
#             topic = sns.Topic(arn)
#             x = dt.datetime.now()
#             message = {
#             "default": "Sample fallback message",
#             "email": message

#             }
#             response = topic.publish(Message=str(json.dumps(message)), Subject="Alert", MessageStructure='json')
#             return response
#         from botocore.exceptions import ClientError
#         SENDER = "Competitions | Aakaar IIT Bombay <competition@aakaariitbombay.org>"
#         RECIPIENT = email
        
        

#         AWS_REGION = "us-east-1"

#         SUBJECT = "BridgeIT Competition | Aakaar IIT Bombay"
    

#         BODY_HTML=("""
#     <!DOCTYPE html>
#     <html lang="en">

#     <head>
#         <meta charset="UTF-8">
#         <meta http-equiv="X-UA-Compatible" content="IE=edge">
#         <meta name="viewport" content="width=device-width, initial-scale=1.0">

#         <meta name="msapplication-TileColor" content="#da532c">
#         <meta name="theme-color" content="#ffffff">

       
#     </head>

#     <body>
#         <div class="text">

        

#             <p>Greetings from Aakaar IIT Bombay!</p>
#         <p>Thank you for registering for the BridgeIT competition conducted by Aakaar, IIT Bombay.
# </p>
#         <p>To further aid you and clarify any doubts that you guys might have regarding competition, we have created a WhatsApp group for general discussions and doubt-solving. Please refrain from spamming or discussing anything else and keep the discussion relevant.
#         <p>Click on the link below to join the group:  </p>

# </p>
#         <p><a href="https://chat.whatsapp.com/DWq64lMp30R9M7zljD6nWe">https://chat.whatsapp.com/DWq64lMp30R9M7zljD6nWe</a> </p>  
#         <p>The problem statement is also included below:  </p>

# <span><a href="https://drive.google.com/file/d/1oC9w4GKXvwbr1OV6mfRh4qdiEnKumi36/view?usp=sharing">Problem Statement</a></span> </p>  
#     <br>
#         <p>for any queries, contact: <a href="mailto:competition@aakaariitbombay.org">competition@aakaariitbombay.org</a>  </p>
#     <p>Dhruvi Amaliya (8905563675) or Dhananjay Kumar (9693237892)	<br>
# Competitions Head, Aakaar 2023

#    <br>
  

#     Thanks and regards,  <br>
     
#         Aakaar 2023,  <br>
#         IIT Bombay]

#     </p>
#         </div>

#     </body>

#     </html>
#     """)
        


#     # The character encoding for the email.
#         CHARSET = "UTF-8"
        
#         # Create a new SES resource and specify a region.
#         client = boto3.client('ses',region_name=AWS_REGION)
        
#         # Try to send the email.
#         try:
#         #Provide the contents of the email.
#                 response = client.send_email(
#                 Destination={
#                     'ToAddresses': [
#                         RECIPIENT,
#                     ]
            
#                 },
#                 Message={
#                     'Body': {
#     #                     'Text': {
#     #                         'Charset': CHARSET,
#     #                         'Data': BODY_TEXT,
#     #                     },
#                         'Html': {
#                         'Charset': CHARSET,
#                         'Data': BODY_HTML,
#                     },
#                     },
#                     'Subject': {
#                         'Charset': CHARSET,
#                         'Data': SUBJECT,
#                     },
#                 },
#                 Source=SENDER,
    
#         )
#     # Display an error if something goes wrong.	
#         except ClientError as e:
#             print(e.response['Error']['Message'])
#         else:
#             print("sent! Message ID:" ),
#             print(response['MessageId'])

    return  redirect('bridgeit')
    


def conquerit(request):
    global re_url
    re_url=request.path
    user = request.user
    is_filled_conquerit = False
    if user.is_authenticated:
        email = user.email
        is_filled_conquerit = len(ConquerIt.objects.filter(email=email))==1

#    print(is_filled_bridgeit)
    return render(request, "conquerit.html",
    {
        'is_filled_conquerit':is_filled_conquerit
    })


def conquerit_reg(request):
    if request.method == "POST":

        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = ConquerIt(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2,
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4,  ref=ref)
        response.save()

        import boto3
        from botocore.exceptions import ClientError
        SENDER = "Competitions | Aakaar IIT Bombay <competition@aakaariitbombay.org>"
        #mail='adityamalhotra521@gmail.com'
        RECIPIENT = email
        name=name1
        

        AWS_REGION = "us-east-1"

    # # The subject line for the email.
        SUBJECT = "Successful Registration for ConquerIT !"
    

        BODY_HTML=("""
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">

        
    </head>

    <body>
        <div class="text">

        

            <p>Hello {name},</p>
        <p>We are pleased to inform you that your registration for ConquerIT has been successful.</p>
        <p>Thank you for being so interested in this exciting event. </p>
        
    <br>
        <p>If you have any questions or concerns, please don't hesitate to reach out to us through the mail: <a href="mailto:competition@aakaariitbombay.org">competition@aakaariitbombay.org</a>  </p>
    <p>We look forward to seeing you at ConquerIT and hope that you will find the event to be informative and enjoyable.
    </p>
    <br>

    <p>Best regards,  <br>
        [Competition Manager <br>
        Aakaar 2023,  <br>
        IIT Bombay]

    </p>
        </div>

    </body>

    </html>
    """.format(name=name))
        


    # The character encoding for the email.
        CHARSET = "UTF-8"
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=AWS_REGION)
        
        # Try to send the email.
        try:
        #Provide the contents of the email.
                response = client.send_email(
                Destination={
                    'ToAddresses': [
                        RECIPIENT,
                    ]
            
                },
                Message={
                    'Body': {
    #                     'Text': {
    #                         'Charset': CHARSET,
    #                         'Data': BODY_TEXT,
    #                     },
                        'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER,
    
        )
    # Display an error if something goes wrong.	
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("sent! Message ID:" ),
            print(response['MessageId'])
    return  redirect('conquerit')


def login_soln(request):
    return redirect(re_url)
