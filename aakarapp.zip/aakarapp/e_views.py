from urllib import request
from django.http import HttpResponse
from django.shortcuts import render, redirect
from allauth.socialaccount.models import SocialAccount

## import data tables from database
from .models import Submission , Seismic ,BridgeIt ,ConquerIt


# Create your views here.


def registerLogiq(request):
    return render(request, "submission.html")

def index(request):
    user = request.user
    is_filled = False 
    is_filled_seismic=False
    is_filled_bridgeit=False
    is_filled_conquerit=False
    if user.is_authenticated:
        email = user.email
        is_filled = len(Submission.objects.filter(email=email))==1
        is_filled_seismic = len(Seismic.objects.filter(email=email))==1
        is_filled_bridgeit=len(BridgeIt.objects.filter(email=email))==1
        is_filled_conquerit=len(ConquerIt.objects.filter(email=email))==1

    print(is_filled)

    return render(request, "index.html",
    {
        'is_filled':is_filled,
        'is_filled_seismic':is_filled_seismic,
        'is_filled_bridgeit':is_filled_bridgeit,
        'is_filled_conquerit':is_filled_conquerit
    })

def logiq(request):
    user = request.user
    is_filled = False 
    if user.is_authenticated:
        email = user.email
        is_filled = len(Submission.objects.filter(email=email))==1
    return render(request, "logiq.html",
    {
        'is_filled':is_filled
    })


def submitted(request):
    if request.method == "POST":
        user = request.user
        name = request.POST.get('name', '')
        email = user.email
        colgName = request.POST.get('colgName', '')
        branch = request.POST.get('branch', '')
        mobileNo = request.POST.get('mobileNo', '')
        # mail = request.POST.get('mail', '')
        program = request.POST.get('program', '')
        year = request.POST.get('year', '')
        address = request.POST.get('address', '')
        roll_no = request.POST.get('roll_no', '')
        ref=request.POST.get('ref','')
        response = Submission(name=name, email=email, colgName=colgName,  branch=branch, mobileNo=mobileNo,
                              year=year, roll_no=roll_no, address=address, program=program,ref=ref)
        response.save()

    return  redirect('index')


def seismic(request):
    user = request.user
    is_filled_seismic = False 
    if user.is_authenticated:
        email = user.email
        is_filled_seismic = len(Seismic.objects.filter(email=email))==1
        
  
    return render(request, "seismic.html",
    {
        'is_filled_seismic':is_filled_seismic
    })


def seismic_reg(request):
    if request.method == "POST":
        
        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        category = request.POST.get('category', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = Seismic(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2, 
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4, category=category, ref=ref)
        response.save()
      
        cat=response.category
        t=response.team
        # if response.category==1:
        #     print('i am category',category)

    
        import datetime as dt
        import boto3
        def publish_message(message):
            arn = ''
            sns = boto3.resource('sns', aws_access_key_id="AKIA3TGK5AWKEZFOA2NH", 
                                aws_secret_access_key="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",
                                region_name='ap-south-1')
            topic = sns.Topic(arn)
            x = dt.datetime.now()
            message = {
                "default": "Sample fallback message",
                "email": message
            
            }
            response = topic.publish(Message=str(json.dumps(message)), Subject="Alert", MessageStructure='json')
            return response
        from botocore.exceptions import ClientError
        # Replace sender@example.com with your "From" address.
        # This address must be verified with Amazon SES.
        SENDER = "Competition Aakaar IIT Bombay<competition@aakaariitbombay.org>"
        mail= [response.email1,response.email2,response.email3,response.email4]
        sent = 0
        num = -1
        for i in mail:
            num +=1
            RECIPIENT = i
            
            AWS_REGION = "us-east-1"
            # # The subject line for the email.
            SUBJECT = "Problem Statement of SeismiC Competition (Category {cat}) | Aakaar IIT Bombay".format(cat=cat)
                #text = ("Dear " + "\033[1m" +name[0]+ "\033[0m" + ","+"\n\nThank you for registering for the Revit Architecture competition conducted by Aakaar,\nIIT Bombay in association with Bimlabs Global.\n\nParticipants will get a chance of winning prizes worth " + "\033[1m" + '₹ 20,000' + "\033[0m" + "\nAlong with Scholarships on courses worth " + "\033[1m" + '₹ 13L+!! ' + "\033[0m" + " \nAlso, get the opportunity to get  " + "\033[1m" + '3 Month Online training + 1-month Internship + Placement Training + Minimum 3 Interviews at BIM Companies in India,' + "\033[0m" + "\n\n" + "\033[1m" + 'Please find the problem statement below link: \n' + "\033[0m" + " https://bit.ly/Revit-Problem-Statement \nSubmission Link:  https://bit.ly/revit-submission \nSubmission Deadline: " + "\033[1m" + '25 November 2022 ' + "\033[0m" + " \nFor any queries,\nContact: competition@aakaariitbombay.org \n\nAll the best !!! \n\nRegards")
            # The email body for recipients with non-HTML email clients.
            #     BODY_TEXT = ( "dear"+name[num]
            # #                 )
            BODY_HTML=("""<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="msapplication-TileColor" content="#da532c">
            <meta name="theme-color" content="#ffffff">
            
        </head>
        <body>
            
                <p>Hello {t} !,<br>Thank you for registering for the SeismiC competition conducted by Aakaar, IIT Bombay.</p>
                <p></p>
                <div class="text">
                
                <p>Participants have to design and build a structure that can withstand maximum earthquake acceleration and shows minimum inter-storey drift. Advanced earthquake-resistance strategies like cross bracing, base isolation, tuned mass dampers, or any other cutting-edge strategy that would be highly valued, should be included in the model.
                </p>
                <p></p>
                <p>Participants will get a chance of winning prizes worth <strong>₹ 40,000!.</strong> <br>
                    Along with many more incentives.</p>
                <p></p>
                </div>
                <p>Please find the problem statement below: <br>
                    <a href="https://competition.aakaariitbombay.org/static/pdfs/seismic{cat}.pdf">Category{cat}-Problem Statement link</a>
                </p>
                <div class="text">
                <p>For queries and clarifications, please drop an email to <a href="mailto:competition@aakaariitbombay.org">
                        competition@aakaariitbombay.org </a> </p>
                
                <p>Thanks and regards,<br> Team Competition, <br>
                    Aakaar 2023, <br>
                    IIT Bombay.</p>
            </div>
        </body>
        </html>
            """).format(t=t,cat=cat)
            CHARSET = "UTF-8"
            # Create a new SES resource and specify a region.
            client = boto3.client('ses',region_name=AWS_REGION)
            # Try to send the email.
            try:
            #Provide the contents of the email.
                response = client.send_email(
                    Destination={
                        'ToAddresses': [
                            RECIPIENT,
                        ],
                    },
                    Message={
                        'Body': {
            #                     'Text': {
            #                         'Charset': CHARSET,
            #                         'Data': BODY_TEXT,
            #                     },
                            'Html': {
                            'Charset': CHARSET,
                            'Data': BODY_HTML,
                        },
                        },
                        'Subject': {
                            'Charset': CHARSET,
                            'Data': SUBJECT,
                        },
                    },
                    Source=SENDER,
                # If you are not using a configuration set, comment or delete the
                # following line
            #         ConfigurationSetName=CONFIGURATION_SET,
            )
            # Display an error if something goes wrong.	
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                sent +=1
                print("Email",sent,"sent! Message ID:" ),
                print(response['MessageId'])
    return redirect('seismic')




    
def bridgeit(request):
    user = request.user
    is_filled_bridgeit = False 
    if user.is_authenticated:
        email = user.email
        is_filled_bridgeit = len(BridgeIt.objects.filter(email=email))==1
        
    print(is_filled_bridgeit)
    return render(request, "bridgeit.html",
    {
        'is_filled_bridgeit':is_filled_bridgeit
    })
    
    
def bridgeit_reg(request):
    if request.method == "POST":
        
        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = BridgeIt(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2, 
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4,  ref=ref)
        response.save()


        import boto3
        from botocore.exceptions import ClientError
        SENDER = "Competitions | Aakaar IIT Bombay <competition@aakaariitbombay.org>"
        #mail='adityamalhotra521@gmail.com'
        RECIPIENT = email1
        name=name1
        

        AWS_REGION = "us-east-1"

    # # The subject line for the email.
        SUBJECT = "Successful Registration for BridgeIT !"
    

        BODY_HTML=("""
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">

        
    </head>

    <body>
        <div class="text">

        

            <p>Hello {name},</p>
        <p>We are pleased to inform you that your registration for BridgeIT has been successful.</p>
        <p>Thank you for being so interested in this exciting event. </p>
        <p>Please proceed with the payment process as soon as possible to confirm your attendance. Payment details can be found on the registration page or through the link given below. </p>
        <p><a href="https://forms.gle/6xMqRGd2apJynEtw9">https://forms.gle/6xMqRGd2apJynEtw9</a> </p>  
    <br>
        <p>If you have any questions or concerns, please don't hesitate to reach out to us through the mail: <a href="mailto:competition@aakaariitbombay.org">competition@aakaariitbombay.org</a>  </p>
    <p>We look forward to seeing you at ConquerIT and hope that you will find the event to be informative and enjoyable.
    </p>
    <br>

    <p>Best regards,  <br>
        [Competition Manager <br>
        Aakaar 2023,  <br>
        IIT Bombay]

    </p>
        </div>

    </body>

    </html>
    """.format(name=name))
        


    # The character encoding for the email.
        CHARSET = "UTF-8"
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=AWS_REGION)
        
        # Try to send the email.
        try:
        #Provide the contents of the email.
                response = client.send_email(
                Destination={
                    'ToAddresses': [
                        RECIPIENT,
                    ]
            
                },
                Message={
                    'Body': {
    #                     'Text': {
    #                         'Charset': CHARSET,
    #                         'Data': BODY_TEXT,
    #                     },
                        'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER,
    
        )
    # Display an error if something goes wrong.	
        except ClientError as e:
	    print("in error")
   #         return HttpResponse("Mail not sent ! please contact competition@aakaariitbombay.org")
        else:
	    print("in else")
    #       return HttpResponse("Mail successfully sent ! If not found in inbox please check in promotions or spam ")

    return  redirect('bridgeit')



def conquerit(request):
    user = request.user
    is_filled_conquerit = False
    if user.is_authenticated:
        email = user.email
        is_filled_conquerit = len(ConquerIt.objects.filter(email=email))==1

#    print(is_filled_bridgeit)
    return render(request, "conquerit.html",
    {
        'is_filled_conquerit':is_filled_conquerit
    })


def conquerit_reg(request):
    if request.method == "POST":

        user = request.user
        email = user.email
        name1 = request.POST.get('name1', '')
        colg1 = request.POST.get('colg1', '')
        email1 = request.POST.get('email1', '')
        contact1 = request.POST.get('contact1', '')
        ref = request.POST.get('ref', '')
        team = request.POST.get('team', '')
        name2 = request.POST.get('name2', '')
        colg2 = request.POST.get('colg2', '')
        email2 = request.POST.get('email2', '')
        contact2 = request.POST.get('contact2', '')
        name3 = request.POST.get('name3', '')
        colg3 = request.POST.get('colg3', '')
        email3 = request.POST.get('email3', '')
        contact3 = request.POST.get('contact3', '')
        name4 = request.POST.get('name4', '')
        colg4 = request.POST.get('colg4', '')
        email4 = request.POST.get('email4', '')
        contact4 = request.POST.get('contact4', '')
        response = ConquerIt(team=team, email=email, name1=name1, email1=email1, colg1=colg1, contact1=contact1, name2=name2, email2=email2, colg2=colg2, contact2=contact2,
                              name3=name3, email3=email3, colg3=colg3, contact3=contact3, name4=name4, email4=email4, colg4=colg4, contact4=contact4,  ref=ref)
        response.save()

        import boto3
        from botocore.exceptions import ClientError
        SENDER = "Competitions | Aakaar IIT Bombay <competition@aakaariitbombay.org>"
        #mail='adityamalhotra521@gmail.com'
        RECIPIENT = email1
        name=name1
        

        AWS_REGION = "us-east-1"

    # # The subject line for the email.
        SUBJECT = "Successful Registration for ConquerIT !"
    

        BODY_HTML=("""
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">

        
    </head>

    <body>
        <div class="text">

        

            <p>Hello {name},</p>
        <p>We are pleased to inform you that your registration for ConquerIT has been successful.</p>
        <p>Thank you for being so interested in this exciting event. </p>
        <p>Please proceed with the payment process as soon as possible to confirm your attendance. Payment details can be found on the registration page or through the link given below. </p>
        <p><a href="https://forms.gle/iunnVQDVxRq6YNhe8">https://forms.gle/iunnVQDVxRq6YNhe8</a> </p>  
    <br>
        <p>If you have any questions or concerns, please don't hesitate to reach out to us through the mail: <a href="mailto:competition@aakaariitbombay.org">competition@aakaariitbombay.org</a>  </p>
    <p>We look forward to seeing you at ConquerIT and hope that you will find the event to be informative and enjoyable.
    </p>
    <br>

    <p>Best regards,  <br>
        [Competition Manager <br>
        Aakaar 2023,  <br>
        IIT Bombay]

    </p>
        </div>

    </body>

    </html>
    """).format(name=name)
        


    # The character encoding for the email.
        CHARSET = "UTF-8"
        
        # Create a new SES resource and specify a region.
        client = boto3.client('ses',region_name=AWS_REGION)
        
        # Try to send the email.
        try:
        #Provide the contents of the email.
                response = client.send_email(
                Destination={
                    'ToAddresses': [
                        RECIPIENT,
                    ]
            
                },
                Message={
                    'Body': {
    #                     'Text': {
    #                         'Charset': CHARSET,
    #                         'Data': BODY_TEXT,
    #                     },
                        'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER,
    
        )
    # Display an error if something goes wrong.	
        except ClientError as e:
            return print("error")
        else:
            print("sent! Message ID:" ),
            print(response['MessageId'])
    return  redirect('conquerit')
